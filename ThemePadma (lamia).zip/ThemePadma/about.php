<?php
/**
 * Template Name: About
 */
get_header();?>
    <!-- menu part end -->
    <!-- search option -->
    <section class="container search">
      <div class="row">
        <div class="col-sm-8">

        </div>
        <div class="col-sm-4">
          <form action="">
            <input type="text" value="<?= get_search_query();?>" name="s">
            <button>search</button>
          </form>
        </div>
      </div>
    </section>
    <!-- marquee -->
    |<section class="container">
      <marquee behavior="direction">
      <?php dynamic_sidebar('mark'); ?>
        


      </marquee>
    </section>
   
    <!-- photo part end -->
    <section class="container photo">
  <div class="row">
  <div class="col-sm-5">
          <?php  dynamic_sidebar('photoimg10');  ?>
        </div>
        <div class="col-sm-2">
           <?php  dynamic_sidebar('phototitle1');  ?>
        </div>
        <div class="col-sm-5">
           <?php  dynamic_sidebar('photoimg20');  ?>
        </div>
  </div>
  <!-- news slider part start -->
  
    <?php
    $qry1 = new WP_Query([
        'post_type'=>'post',
        'category_name'=>'padma'
    ]); 
    
    ?>
<div id="carouselExampleControls" class="carousel slide" data-bs-ride="carousel">
  <div class="carousel-inner">
<?php $x = 0;
while ($qry1->have_posts()) {$qry1->the_post();
    $x++; ?>
    <div class="carousel-item <?= ($x==1)?'active':''?>">
        <?php the_title(); ?>
      <!-- <img src="..." class="d-block w-100" alt="..."> -->
    </div>
    <?php } ?>

     <!-- <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div>
    <div class="carousel-item">
      <img src="..." class="d-block w-100" alt="...">
    </div> -->
  </div> 
  <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Previous</span>
  </button>
  <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleControls" data-bs-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="visually-hidden">Next</span>
  </button>
</div>

  <!-- news slider part end-->
  </section>
  <!-- footer part start -->
  <?php get_footer(); ?>
  
 